//
//  thebetter8Ball2App.swift
//  thebetter8Ball2
//
//  Created by Sam Isham on 9/29/23.
//

import SwiftUI

@main
struct thebetter8Ball2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
